const signaler <- object signaler
  process
    shared.goforit
  end process
end signaler
