const first <- object first
  
end first
