const foo <- immutable object foo
  export op banana
  end banana
end foo

export foo 
