const hello <- object hello
  initially
    stdout.putstring["hello\n"]
  end initially
end hello
