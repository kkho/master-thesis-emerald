const foo <- 23 23 23
