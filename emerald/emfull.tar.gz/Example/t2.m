const tx <- object tx
  initially
    var x : Ident
    const foo <- x.asString
  end initially
end tx
