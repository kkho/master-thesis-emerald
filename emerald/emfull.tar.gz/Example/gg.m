
const etype <- Directory
const ggd <- class ggd (gd)
end ggd

const test <- object test
  const t <- ggd.create
  process
    t.addmember[nil]
    t.addmember[nil]
  end process
end test
