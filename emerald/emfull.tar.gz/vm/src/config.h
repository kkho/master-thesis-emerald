/*
 * Architecture specific definitions required for porting the Emerald
 * runtime.
 */

#ifndef _EMERALD_CONFIG_H
#define _EMERALD_CONFIG_H


#endif  /* _EMERALD_CONFIG_H */
