/*
 * HELLO.C
 *
 * a silly primitive C call.  Can go away when we have real ones.
 */

#include <stdio.h>
#include "hello.h"

void hello(void) {
	printf("Hello world.\n");
}

