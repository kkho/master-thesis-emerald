% 
% @(#)Unix.m	1.1  3/6/91
%
export Unix to "Builtins"

const Unix == immutable object Unix

  export operation removeFile [fn : String]
    assert false
  end removeFile
end Unix
